The solution and project was made with Visual Studio 2015 RC, but it uses the Visual C++ 2013 (Windows XP compatibility) compiler.

PS: The code will most likely work cross-platform (as long as it supports C++11) since there are no compiler-specific tweaks or non-stdlib APIs used.

Cheers! :-)

- Josh